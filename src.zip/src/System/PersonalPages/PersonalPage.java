package System.PersonalPages;

import System.Users.User;

import java.util.List;

public class PersonalPage {

     private IPageAvailable pageAvailable;
     private List <User> followers;

    //Methods
    public void follow(User user){

    } //UC-7

    public void unfollow(User user) { } //UC-8
}
