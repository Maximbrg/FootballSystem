package System.Exeptions;

public class wrongPasswordException extends Exception{
}
