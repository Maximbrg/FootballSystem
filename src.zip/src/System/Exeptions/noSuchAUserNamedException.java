package System.Exeptions;

public class noSuchAUserNamedException extends Exception {
}
