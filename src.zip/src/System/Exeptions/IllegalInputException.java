package System.Exeptions;

public class IllegalInputException extends Exception {
}
