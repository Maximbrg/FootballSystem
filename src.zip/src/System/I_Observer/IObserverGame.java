package System.I_Observer;

public interface IObserverGame {

    void update();
}
