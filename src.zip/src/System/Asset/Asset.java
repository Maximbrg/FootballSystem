package System.Asset;

public interface Asset {

    void edit();
}
