package System.Users;

import System.I_Observer.IObserverGame;

public class Fan extends User implements IObserverGame {

    private String name;

    @Override
    public void update() {

    }

}
