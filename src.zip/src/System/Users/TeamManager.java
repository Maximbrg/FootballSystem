package System.Users;

import System.Asset.Asset;
import System.I_Observer.IObserverTeam;

public class TeamManager extends User implements Asset, IObserverTeam {

    private String name;

    @Override
    public void edit() {

    }

    @Override
    public void update() {

    }
}
