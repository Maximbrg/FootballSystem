package System.FootballObjects;

public class LeagueInformation {
}
