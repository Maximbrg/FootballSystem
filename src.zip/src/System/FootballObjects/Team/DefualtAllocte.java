package System.FootballObjects.Team;

public class DefualtAllocte implements ITeamAllocatePolicy {

    public void setTeamPolicy(){
    }

}
