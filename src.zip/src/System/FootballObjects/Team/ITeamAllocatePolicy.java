package System.FootballObjects.Team;

public interface ITeamAllocatePolicy {

    void setTeamPolicy();
}
