package System.FootballObjects.Event;

public class YellowCard extends AEvent {
}
