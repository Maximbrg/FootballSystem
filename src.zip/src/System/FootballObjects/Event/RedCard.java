package System.FootballObjects.Event;

public class RedCard extends AEvent {
}
