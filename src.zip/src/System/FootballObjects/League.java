package System.FootballObjects;

public class League {

    private String name;

    public String getName() {
        return name;
    }
}
