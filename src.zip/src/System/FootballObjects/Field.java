package System.FootballObjects;

public class Field {

    private int id;
    private String name;
}
