package System;

public class FanOfTeam {
}
