package System.Users;

public enum Status {

    ACTIVE,
    INACTIVE
}
