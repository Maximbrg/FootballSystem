package System.Users;

import System.PersonalPages.PersonalPage;

import java.util.List;

public class User {

    private  int id;
    private String password;
    private String userName;
   // private List<PersonalPage> personalPages;
    private Status status;


    //<editor-fold desc="Constructor">
    /**
     * Constructor
     */
    public User(int id, String password, String userName, Status status) {
        this.id = id;
        this.password = password;
        this.userName = userName;
        this.status = status;
    }
    //</editor-fold>

    //<editor-fold desc="Setters">
    public void setId(int id) {
        this.id = id;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public void setStatus(Status status) {
        this.status = status;
    }
    //</editor-fold>

    //<editor-fold desc="Getters">
    public int getId() {
        return id;
    }

    public String getPassword() {
        return password;
    }

    public String getUserName() {
        return userName;
    }

    public Status getStatus() {
        return status;
    }
    //</editor-fold>


    // Methods

    public boolean sumbitReport(String report){
        return true;
    } //UC-11

    public String showSearchHistory(){
        return "";
    } //UC-12

    public String showPersonalSDetails(){
        return "";
    } //UC-13

    public void  editPersonalDetails(/* need to add arguments of the new details */ ){

    } //UC-

    /**
     *
     * @param o - represent the value we need to set
     * @param s - represent the attribute name we need to change
     */
    public void editUser(Object o,String s) {
        if(s.equals("id"))
            this.setId((Integer) o);
        if(s.equals("password"))
            this.setPassword((String) o);
        if(s.equals("userName"))
            this.setUserName((String) o);
        if (s.equals("status"))
            this.setStatus((Status) o);
    }
}
