package System.Users;

import System.Asset.Asset;
import System.PersonalPages.IPageAvailable;
import System.PersonalPages.PersonalPage;

import java.util.Date;

public class Player extends User implements Asset, IPageAvailable {

    private String name;
    private Date birthDate;
    private String role;
    private PersonalPage personalPage;
    private  int salary;


    //<editor-fold desc="Constructor">
    /**
     * Constructor
     * @param id
     * @param password
     * @param userName
     * @param status
     * @param name
     * @param birthDate
     * @param role
     * @param personalPage
     * @param salary
     */
    public Player(int id, String password, String userName, Status status, String name, Date birthDate, String role, PersonalPage personalPage, int salary) {
        super(id, password, userName, status);
        this.name = name;
        this.birthDate = birthDate;
        this.role = role;
        this.personalPage = personalPage;
        this.salary = salary;
    }

    //</editor-fold>

    //<editor-fold desc="Setters">
    public void setName(String name) {
        this.name = name;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setPersonalPage(PersonalPage personalPage) {
        this.personalPage = personalPage;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }
    //</editor-fold>

    //<editor-fold desc="Getters">
    public String getName() {
        return name;
    }

    public Date getBirthDate() {
        return birthDate;
    }

    public String getRole() {
        return role;
    }

    public PersonalPage getPersonalPage() {
        return personalPage;
    }

    public int getSalary() {
        return salary;
    }
    //</editor-fold>


    @Override
    public String showDetails() {
        return null;
    }

    @Override
    public void edit(Object o,String s) {
        this.editUser(o,s);
        //<editor-fold desc="Player attributes edit">
        if(s.equals("name"))
        this.setName(((String) o));
    if(s.equals("birthDate"))
        this.setBirthDate(((Date) o));
    if(s.equals("role"))
        this.setRole((String) o);
    if(s.equals("personalPage"))
        this.setPersonalPage((PersonalPage) o);
    if(s.equals("salary"))
        this.setSalary((Integer) o);

        //</editor-fold>
    }

    @Override
    public void addSalary(int amountToSet) {
        this.setSalary(amountToSet);
    }
}
