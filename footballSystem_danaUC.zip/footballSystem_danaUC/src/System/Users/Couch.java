package System.Users;

import System.Asset.Asset;
import System.PersonalPages.IPageAvailable;
import System.PersonalPages.PersonalPage;

public class Couch extends User implements Asset, IPageAvailable {

    private String name;
    private String preparation;
    private String role;
    private PersonalPage personalPage;
    private  int salary;


    //<editor-fold desc="Constructor">
    /**
     * Constructor
     * @param id
     * @param password
     * @param userName
     * @param status
     * @param name
     * @param preparation
     * @param role
     * @param personalPage
     * @param salary
     */
    public Couch(int id, String password, String userName, Status status, String name, String preparation, String role, PersonalPage personalPage, int salary) {
        super(id, password, userName, status);
        this.name = name;
        this.preparation = preparation;
        this.role = role;
        this.personalPage = personalPage;
        this.salary = salary;
    }

    //</editor-fold>

    //<editor-fold desc="Setters">
    public void setName(String name) {
        this.name = name;
    }

    public void setPreparation(String preparation) {
        this.preparation = preparation;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setPersonalPage(PersonalPage personalPage) {
        this.personalPage = personalPage;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }
    //</editor-fold>

    //<editor-fold desc="Getters">
    public String getName() {
        return name;
    }

    public String getPreparation() {
        return preparation;
    }

    public String getRole() {
        return role;
    }

    public PersonalPage getPersonalPage() {
        return personalPage;
    }

    public int getSalary() {
        return salary;
    }
    //</editor-fold>

    @Override
    public String showDetails() {
        return null;
    }

    @Override
    public void edit(Object o,String s) {
        this.editUser(o,s);
        //<editor-fold desc="Couch attributes edit">
        if(s.equals("name"))
            this.setName(((String) o));
        if(s.equals("preparation"))
            this.setPreparation((String) o);
        if(s.equals("role"))
            this.setRole((String) o);
        if(s.equals("personalPage"))
            this.setPersonalPage((PersonalPage) o);
        if(s.equals("salary"))
            this.setSalary((Integer) o);

        //</editor-fold>
    }

    @Override
    public void addSalary(int amountToSet) {
        this.setSalary(amountToSet);
    }
}
