package System.Users;

import System.Asset.Asset;
import System.I_Observer.IObserverTeam;

public class TeamManager extends User implements Asset, IObserverTeam {

    private String name;
    private  int salary;

    //<editor-fold desc="Constructor">
    /**
     * Constructor
     * @param id
     * @param password
     * @param userName
     * @param status
     * @param name
     * @param salary
     */
    public TeamManager(int id, String password, String userName, Status status, String name, int salary) {
        super(id, password, userName, status);
        this.name = name;
        this.salary = salary;
    }
    //</editor-fold>

    //<editor-fold desc="Setters">
    public void setName(String name) {
        this.name = name;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }
    //</editor-fold>

    //<editor-fold desc="Getters">
    public String getName() {
        return name;
    }

    public int getSalary() {
        return salary;
    }
    //</editor-fold>

    @Override
    public void edit(Object o,String s) {
        this.editUser(o,s);
        //<editor-fold desc="TeamManager attributes edit">
        if(s.equals("name"))
            this.setName(((String) o));
        if(s.equals("salary"))
            this.setSalary((Integer) o);
        //</editor-fold>
    }

    @Override
    public void addSalary(int amountToSet) {
        this.setSalary(amountToSet);
    }

    @Override
    public void update() {

    }


}
