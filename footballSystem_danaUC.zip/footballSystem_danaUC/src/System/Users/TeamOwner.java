package System.Users;

import System.Asset.Asset;
import System.FootballObjects.Team.Team;
import System.I_Observer.IObserverTeam;

import java.util.List;

public class TeamOwner extends User implements Asset, IObserverTeam {

    private String name;
    private Couch selfCouch; // if he also Couch otherwise null
    private TeamManager selfTeamManager; // if he also TeamManager otherwise null
    private Player selfPlayer; // if he also Player otherwise null
    private List<Team> teamList;


    //<editor-fold desc="Constructor">
    /**
     * Constructor
     * @param id
     * @param password
     * @param userName
     * @param status
     * @param name
     * @param selfCouch
     * @param selfTeamManager
     * @param selfPlayer
     * @param teamList
     */
    public TeamOwner(int id, String password, String userName, Status status, String name, Couch selfCouch, TeamManager selfTeamManager, Player selfPlayer, List<Team> teamList) {
        super(id, password, userName, status);
        this.name = name;
        this.selfCouch = selfCouch;
        this.selfTeamManager = selfTeamManager;
        this.selfPlayer = selfPlayer;
        this.teamList = teamList;
    }
    //</editor-fold>

    //<editor-fold desc="Setters">
    public void setName(String name) {
        this.name = name;
    }

    public void setSelfCouch(Couch selfCouch) {
        this.selfCouch = selfCouch;
    }

    public void setSelfTeamManager(TeamManager selfTeamManager) {
        this.selfTeamManager = selfTeamManager;
    }

    public void setSelfPlayer(Player selfPlayer) {
        this.selfPlayer = selfPlayer;
    }

    public void setTeamList(List<Team> teamList) {
        this.teamList = teamList;
    }
    //</editor-fold>

    //<editor-fold desc="Getters">
    public String getName() {
        return name;
    }

    public Couch getSelfCouch() {
        return selfCouch;
    }

    public TeamManager getSelfTeamManager() {
        return selfTeamManager;
    }

    public Player getSelfPlayer() {
        return selfPlayer;
    }

    public List<Team> getTeamList() {
        return teamList;
    }
    //</editor-fold>

    //Methods
    public void openTeam(Team team){

    } //UC-23

    public void sendFinancialReport(Team team){
    } //UC-24 /* need to open a class of financial reports and store their the financial reports and that all football association can view it */


    @Override
    public void edit(Object o, String str) {

    }

    @Override
    public void addSalary(int amountToSet) {

    }

    @Override
    public void update() {

    }


}
