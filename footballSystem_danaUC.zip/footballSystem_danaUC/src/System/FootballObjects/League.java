package System.FootballObjects;

public class League {

    private String name;
}
