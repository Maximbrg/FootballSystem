package System.FootballObjects.Team;

import System.Asset.Asset;
import System.I_Observer.IObserverTeam;
import System.I_Observer.ISubjectTeam;
import System.PersonalPages.IPageAvailable;
import System.PersonalPages.PersonalPage;
import System.Users.*;
import org.omg.CORBA.Object;

import java.util.HashMap;
import java.util.List;

public class Team implements IPageAvailable, ISubjectTeam {

    private static int id;
    private String name;
    private Status status;
    private PersonalPage personalPage;
    private List<Asset> assets;
    private List<IObserverTeam> iObserverTeams;
    private List<TeamOwner > teamOwnerList;
    private List<TeamManager> teamManagersList;


    //<editor-fold desc="Constructor">
    /**
     * Constructor
     * @param name
     * @param status
     * @param personalPage
     * @param assets
     * @param iObserverTeams
     * @param teamOwnerList
     * @param teamManagersList
     */
    public Team(String name, Status status, PersonalPage personalPage, List<Asset> assets, List<IObserverTeam> iObserverTeams, List<TeamOwner> teamOwnerList, List<TeamManager> teamManagersList) {
        this.name = name;
        this.status = status;
        this.personalPage = personalPage;
        this.assets = assets;
        this.iObserverTeams = iObserverTeams;
        this.teamOwnerList = teamOwnerList;
        this.teamManagersList = teamManagersList;
    }

    /**
     * default constructor
     */
    public Team() {

    }
    //</editor-fold>

    //<editor-fold desc="Setters">
    public static void setId(int id) {
        Team.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public void setPersonalPage(PersonalPage personalPage) {
        this.personalPage = personalPage;
    }

    public void setAssets(List<Asset> assets) {
        this.assets = assets;
    }

    public void setiObserverTeams(List<IObserverTeam> iObserverTeams) {
        this.iObserverTeams = iObserverTeams;
    }

    public void setTeamOwnerList(List<TeamOwner> teamOwnerList) {
        this.teamOwnerList = teamOwnerList;
    }

    public void setTeamManagersList(List<TeamManager> teamManagersList) {
        this.teamManagersList = teamManagersList;
    }

    //</editor-fold>

    //<editor-fold desc="Getters">
    public static int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public Status getStatus() {
        return status;
    }

    public PersonalPage getPersonalPage() {
        return personalPage;
    }

    public List<Asset> getAssets() {
        return assets;
    }

    public List<IObserverTeam> getiObserverTeams() {
        return iObserverTeams;
    }

    public List<TeamOwner> getTeamOwnerList() {
        return teamOwnerList;
    }

    public List<TeamManager> getTeamManagersList() {
        return teamManagersList;
    }

    //</editor-fold>


    //Methods

    /**
     *
     * @param asset
     * add asset to the team assets
     * according to UC-15
     *
     */
    public void addAsset(Asset asset){
        if(asset!=null)
             this.assets.add(asset);
    } //UC-15

    /**
     *
     * @param asset
     * remove asset from the team assets
     * according to UC-16
     *
     */
    public void removeAsset(Asset asset){
        if(asset!=null)
            this.assets.remove(asset);
    } //UC-16

    /**
     *
     * @param asset
     * @param o
     * @param s
     * according to UC-17
     */
    public void editAsset(Asset asset , Object o,String s ){
        asset.edit(o,s);
    } //UC-17

    /**
     *
     * @param teamOwnerNew
     * according to UC-18
     */
    public void addTeamOwner(TeamOwner teamOwnerNew){
        this.teamOwnerList.add(teamOwnerNew);
    } //UC-18

    /**
     *
     * @param teamOwner
     * according to UC-19
     */
    public void removeTeamOwner(TeamOwner teamOwner){
        this.teamOwnerList.remove(teamOwner);
    } //UC-19

    /**
     *
     * @param teamManagerNew
     * according to UC-20
     */
    public void addTeamManager(TeamManager teamManagerNew){
        this.teamManagersList.add(teamManagerNew);
    } //UC-20

    /**
     *
     * @param teamManager
     * according to UC-21
     */
    public void removeTeamManager(TeamManager teamManager){
        this.teamManagersList.remove(teamManager);
    } //UC-21

    /**
     * according to UC-22
     */
    public void closeTeam(){
        this.setStatus(Status.Close);
    } //UC-22


    @Override
    public String showDetails() {
        return null;
    }

    @Override
    public void removeAlert(User user) {

    }

    @Override
    public void registerAlert(User user) {

    }

    @Override
    public void notifyUsers(User user) {

    }
}
