package System.FootballObjects.Team;

public enum Status {

        Active,
        Close,
        PermantlyClose

}
