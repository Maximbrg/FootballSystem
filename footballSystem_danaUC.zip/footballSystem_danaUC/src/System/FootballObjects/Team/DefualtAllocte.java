package System.FootballObjects.Team;

public class DefualtAllocte {

    public void setTeamPolicy(){
    }
}
