package System.FootballObjects.Team;

public interface IScoreMethodPolicy {

    void setScorePolicy();
}
