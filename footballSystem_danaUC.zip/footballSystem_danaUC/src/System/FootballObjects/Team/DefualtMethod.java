package System.FootballObjects.Team;

public class DefualtMethod implements IScoreMethodPolicy {

    public void setScorePolicy(){

    }
}
