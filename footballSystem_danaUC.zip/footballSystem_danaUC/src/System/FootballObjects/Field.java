package System.FootballObjects;

import System.Asset.Asset;
import System.FootballObjects.Team.Team;

import java.util.List;

public class Field implements Asset {

    private int id;
    private String name;
    private List<Team> homeTeams;

    //<editor-fold desc="constructor">
    /**
     * constructor
     * @param id
     * @param name
     * @param homeTeams
     */
    public Field(int id, String name, List<Team> homeTeams) {
        this.id = id;
        this.name = name;
        this.homeTeams = homeTeams;
    }
    //</editor-fold>

    //<editor-fold desc="Setters">
    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setHomeTeams(List<Team> homeTeams) {
        this.homeTeams = homeTeams;
    }
    //</editor-fold>

    //<editor-fold desc="Getters">
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<Team> getHomeTeams() {
        return homeTeams;
    }


    //</editor-fold>

    @Override
    public void edit(Object o, String str) {

    }

    /**
     * Field doesnt have salary, therefor we dont set the salary attribute and keep it with the initial value=0
     * Thus, we dont implement this method
     * @param amountToSet
     */
    @Override
    public void addSalary(int amountToSet) {

    }
}
