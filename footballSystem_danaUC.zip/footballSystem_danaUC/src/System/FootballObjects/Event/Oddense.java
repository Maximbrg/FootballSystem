package System.FootballObjects.Event;

public class Oddense extends AEvent {
}
