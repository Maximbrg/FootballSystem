package System.FootballObjects.Event;

import java.util.Date;

public abstract class AEvent {
    private int id;
    private Date date;
    private int hour;
    private int minute;

    //Constructor



}
