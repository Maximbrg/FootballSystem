package System.FootballObjects.Event;

public class Injury extends AEvent {
}
