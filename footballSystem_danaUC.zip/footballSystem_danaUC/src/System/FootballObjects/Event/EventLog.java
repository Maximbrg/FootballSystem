package System.FootballObjects.Event;

import java.util.List;

public class EventLog {

    private List<AEvent> aEventList;
}
