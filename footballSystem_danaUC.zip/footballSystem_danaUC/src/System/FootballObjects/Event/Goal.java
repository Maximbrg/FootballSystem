package System.FootballObjects.Event;

public class Goal extends AEvent {
}
