package System.FootballObjects.Event;

public class Offside extends AEvent {
}
