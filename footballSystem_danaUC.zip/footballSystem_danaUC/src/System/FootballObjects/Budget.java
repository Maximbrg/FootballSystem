package System.FootballObjects;

public class Budget {

    private int amount;
}
