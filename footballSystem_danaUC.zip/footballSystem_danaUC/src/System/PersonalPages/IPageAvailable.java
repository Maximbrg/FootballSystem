package System.PersonalPages;

public interface IPageAvailable {

    String showDetails();
}
