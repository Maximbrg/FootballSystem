package System;

import System.Users.User;

public class Report {

    private User user;
    private static int id;
    private String report;
    private String answer;

    //Methods
    public String showReport(){
        return "";
    } //UC-27

    public void answer(){} //UC-27

}
