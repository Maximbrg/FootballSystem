package System.I_Observer;

public interface IObserverTeam {

    void update();
}
