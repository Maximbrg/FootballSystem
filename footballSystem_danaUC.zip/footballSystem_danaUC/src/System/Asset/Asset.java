package System.Asset;

public interface Asset {

    /**
     *
     * @param o - represent the value we need to set
     * @param s - represent the attribute name we need to change
     */
    void edit(Object o,String s);

    /**
     *
     * @param amountToSet - represent the salary that need to be set for the asset
     */
    void addSalary(int amountToSet);

}
